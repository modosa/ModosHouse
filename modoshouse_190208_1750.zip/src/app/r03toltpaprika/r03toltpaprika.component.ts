import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-r03toltpaprika',
  templateUrl: './r03toltpaprika.component.html',
  styleUrls: ['./r03toltpaprika.component.css']
})
export class R03toltpaprikaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
