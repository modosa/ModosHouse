import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MustseeComponent } from './mustsee.component';

describe('MustseeComponent', () => {
  let component: MustseeComponent;
  let fixture: ComponentFixture<MustseeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MustseeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MustseeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
