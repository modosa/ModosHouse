import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { R01babgulyComponent } from './r01babguly/r01babguly.component';
import { R02lacipecsComponent } from './r02lacipecs/r02lacipecs.component';
import { R03toltpaprikaComponent } from './r03toltpaprika/r03toltpaprika.component';

const routes: Routes = [
  { path: 'babgulyas', component: R01babgulyComponent },
  { path: 'lacipecsenye', component: R02lacipecsComponent },
  { path: 'toltottpaprika', component: R03toltpaprikaComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
