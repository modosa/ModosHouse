import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { R02lacipecsComponent } from './r02lacipecs.component';

describe('R02lacipecsComponent', () => {
  let component: R02lacipecsComponent;
  let fixture: ComponentFixture<R02lacipecsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ R02lacipecsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(R02lacipecsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
