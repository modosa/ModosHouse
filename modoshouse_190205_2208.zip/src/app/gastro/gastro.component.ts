import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gastro',
  templateUrl: './gastro.component.html',
  styleUrls: ['./gastro.component.css']
})
export class GastroComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
