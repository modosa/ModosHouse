import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { AppComponent } from './app.component';
import { TextComponent } from './text/text.component';
import { ImageComponent } from './image/image.component';
import { MainComponent } from './main/main.component';
import { NewsComponent } from './news/news.component';
import { WhyusComponent } from './whyus/whyus.component';
import { TestimonialsComponent } from './testimonials/testimonials.component';

@NgModule({
  declarations: [
    AppComponent,
    TextComponent,
    ImageComponent,
    MainComponent,
    NewsComponent,
    WhyusComponent,
    TestimonialsComponent
  ],
  imports: [
    BrowserModule,
    NgbModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
