export class Opinion {
    id: number;
    name: string;
    town: string;
    opi: string;
}