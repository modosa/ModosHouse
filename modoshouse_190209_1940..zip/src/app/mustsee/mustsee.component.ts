import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mustsee',
  templateUrl: './mustsee.component.html',
  styleUrls: ['./mustsee.component.css']
})
export class MustseeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
