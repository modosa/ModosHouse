import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-r02lacipecs',
  templateUrl: './r02lacipecs.component.html',
  styleUrls: ['./r02lacipecs.component.css']
})
export class R02lacipecsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
