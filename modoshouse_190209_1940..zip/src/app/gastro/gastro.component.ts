import { Component, OnInit } from '@angular/core';

declare function opening(): any;
// declare function closing(): any;

@Component({
  selector: 'app-gastro',
  templateUrl: './gastro.component.html',
  styleUrls: ['./gastro.component.css']
})
export class GastroComponent implements OnInit {
  
  constructor() { }

  ngOnInit() {
    opening ();    
    // closing();
  }
}