import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-housing',
  templateUrl: './housing.component.html',
  styleUrls: ['./housing.component.css']
})
export class HousingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
