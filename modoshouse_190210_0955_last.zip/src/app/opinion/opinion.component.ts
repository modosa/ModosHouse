import { Component, OnInit } from '@angular/core';
import { Opinion } from '../../models/opinion';
// import { fakeOpinions } from "../fake-opinions"
import { OpinionService } from '../opinion.service';

@Component({
  selector: 'app-opinion',
  templateUrl: './opinion.component.html',
  styleUrls: ['./opinion.component.css']
})
export class OpinionComponent implements OnInit {

  opinion: Opinion = {
    id: 1,
    name: "Péter",
    town: "Miskolc",
    opi: "A szállás elég kényelmes, minden megvan benne, ami nyaraláskor kellhet. Nem 5 csillagos, de nem is az az ára :)"
  }
  // opinions = fakeOpinions;
  opinions: Opinion[]; 
  constructor(private opinionService: OpinionService) {

   }
  getOpinionsFromServices(): void {
    this.opinions = this.opinionService.getOpinions();
  }
  ngOnInit() {
    this.getOpinionsFromServices();
  }

}
