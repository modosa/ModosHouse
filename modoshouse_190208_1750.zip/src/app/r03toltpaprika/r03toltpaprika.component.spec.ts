import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { R03toltpaprikaComponent } from './r03toltpaprika.component';

describe('R03toltpaprikaComponent', () => {
  let component: R03toltpaprikaComponent;
  let fixture: ComponentFixture<R03toltpaprikaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ R03toltpaprikaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(R03toltpaprikaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
