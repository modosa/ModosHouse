import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { R01babgulyComponent } from './r01babguly.component';

describe('R01babgulyComponent', () => {
  let component: R01babgulyComponent;
  let fixture: ComponentFixture<R01babgulyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ R01babgulyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(R01babgulyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
