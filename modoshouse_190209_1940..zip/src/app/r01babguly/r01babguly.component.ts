import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-r01babguly',
  templateUrl: './r01babguly.component.html',
  styleUrls: ['./r01babguly.component.css']
})
export class R01babgulyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
