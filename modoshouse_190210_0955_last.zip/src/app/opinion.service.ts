import { Injectable } from '@angular/core';
import { fakeOpinions} from './fake-opinions';
import { Opinion } from '../models/opinion';

@Injectable({
  providedIn: 'root'
})
export class OpinionService {
  getOpinions(): Opinion[] {
    return fakeOpinions;
  }
  constructor() { }
}
