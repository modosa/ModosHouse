import { Opinion} from "../models/opinion"
export var fakeOpinions: Opinion[] = [
    {
        id: 1,
        name: "Péter",
        town: "Miskolc",
        opi: "A szállás kényelmes, minden megvan benne, ami nyaraláskor kellhet. Nem 5 csillagos szálloda, de nem is az az ára :-) "
    },
    {
        id: 2,
        name: "Laci",
        town: "Budapest",
        opi: "Jó volt kiszakadni a főváros forgatagából. A szállás és a település a békés, nyugodt hangulatával megfelelő partner volt ebben."
    },
    {
        id: 3,
        name: "Vera",
        town: "Tatabánya",
        opi: "Ha lesz lehetőségem, biztos jövünk máskor is. A tulajdonosok nagyon kedvesek, a szobák kényelmesek, a Balaton gyalog sincs messze. A magasparti panorámát ne hagyja ki senki!"
    },
]