import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HousingComponent } from './housing/housing.component';
import { MustseeComponent } from './mustsee/mustsee.component';
import { GastroComponent } from './gastro/gastro.component';
import { ContactComponent } from './contact/contact.component';
import { OpinionComponent } from './opinion/opinion.component';
import { MainComponent } from './main/main.component';
import { OpinionService } from './opinion.service';
import { R01babgulyComponent } from './r01babguly/r01babguly.component';
import { R02lacipecsComponent } from './r02lacipecs/r02lacipecs.component';
import { R03toltpaprikaComponent } from './r03toltpaprika/r03toltpaprika.component';


@NgModule({
  declarations: [
    AppComponent,
    HousingComponent,
    MustseeComponent,
    GastroComponent,
    ContactComponent,
    OpinionComponent,
    MainComponent,
    R01babgulyComponent,
    R02lacipecsComponent,
    R03toltpaprikaComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
  ],
  providers: [
    OpinionService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
